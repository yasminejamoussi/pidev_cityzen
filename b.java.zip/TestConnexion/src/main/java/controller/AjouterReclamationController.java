package controller;

import Entites.Reclamation;
import Service.ServiceReclamation;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.controlsfx.control.Rating;

import java.io.IOException;
import java.sql.SQLException;

public class AjouterReclamationController {

    @FXML
    private TextField txtemail;
    @FXML
    private Rating myrating;

    @FXML
    private TextField txtmessage;

    @FXML
    private TextField txtnom;

    @FXML
    private TextField txtprenom;
    ServiceReclamation ser=new ServiceReclamation();
    @FXML
    void ajouterReclamation(ActionEvent event) throws SQLException {
        System.out.println("Début de la méthode ajouterReclamation");
        ServiceReclamation ser=new ServiceReclamation();
        String nom = txtnom.getText();
        String prenom = txtprenom.getText();
        String email = txtemail.getText();
        String message = txtmessage.getText();
        String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$";
        if (!nom.isEmpty()&&!prenom.isEmpty()&&!email.isEmpty()&&!message.isEmpty()) {
            System.out.println("Conditions de non-vide satisfaites");

            if(email.matches(emailRegex)) {
                if(ser.isNomUnique(nom)) {
                    System.out.println("Nom unique vérifié");

                    double note= myrating.getRating();
                    Reclamation rec = new Reclamation(txtnom.getText(), txtprenom.getText(), txtemail.getText(), txtmessage.getText(),5,note);
                    try {
                        System.out.println("Tentative d'ajout de réclamation à la base de données");

                        ser.ajouter(rec);
                        txtnom.clear();
                        txtprenom.clear();
                        txtemail.clear();
                        txtmessage.clear();
                        System.out.println("Réclamation ajoutée avec succès");
                    } catch (SQLException e) {
                        System.out.println("Erreur lors de l'ajout de la réclamation à la base de données");
                        e.printStackTrace();
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Titre existant");
                    alert.setHeaderText(null);
                    alert.setContentText("Le titre saisi existe déjà. Veuillez saisir un titre unique.");
                    alert.showAndWait();
                }
            }else {Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Invalid Email.");
                alert.setHeaderText(null);
                alert.setContentText("Invalid Email.");

                alert.showAndWait();
               ;}
        } else {
            // Invalid email, show an alert
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Entree invalid");
            alert.setHeaderText(null);
            alert.setContentText("Veuiller remplir tous les champs.");
            alert.showAndWait();
        }
        txtnom.clear();
        txtprenom.clear();
        txtemail.clear();
        txtmessage.clear();
    }

    @FXML
    private Button btnafficher;
    @FXML
    void afficherReclamation(ActionEvent event) throws IOException {

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/AfficherReclamation.fxml"));
                Parent root = loader.load();
                AfficherReclamationController dc = loader.getController();
                dc.setLbname(txtnom.getText());
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();
                ((Node) (event.getSource())).getScene().getWindow().hide();

                // Fermer la fenêtre actuelle si nécessaire
                // ((Stage) txtnbrplace.getScene().getWindow()).close();
            } catch (IOException e) {
                e.printStackTrace(); // Gérer l'exception correctement
            }
        }

}
